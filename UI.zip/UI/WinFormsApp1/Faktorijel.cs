﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Numerics;

namespace WinFormsApp1
{
    public partial class Faktorijel : UserControl
    {
        public Faktorijel()
        {
            InitializeComponent();
        }
        static BigInteger CalculateFactorialLoop(BigInteger n)
        {
            if (n < 0)
            {
                throw new ArgumentException("Input must be a non-negative integer.");
            }

            BigInteger factorial = 1;
            for (int i = 1; i <= n; i++)
            {
                factorial *=i;
            }

            return factorial;
        }

        static double CalculateFactorialLoop2(int n)
        {
            if (n < 0)
            {
                throw new ArgumentException("Input must be a non-negative integer.");
            }

            double factorial = 1;
            for (int i = 1; i <= n; i++)
            {
                factorial *= i;
            }

            return factorial;
        }
        public static double CalculateFactorialStirling(double n)
        {
            if (n < 0)
            {
                throw new ArgumentException("Input must be a non-negative integer.");
            }
            return Math.Sqrt(2.0 * Math.PI * n) * Math.Pow((n / Math.E), n);
        }
        BigInteger FakText = 0;
        double StirlingBroj = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            int n = int.Parse(textBox4.Text);
            double doubleFak;
            FakText = BigInteger.Parse(textBox4.Text);
            StirlingBroj = Convert.ToDouble(textBox4.Text);
            if (FakText < 0)
            {
                Upisvrijednosti.Show();
                Upisvrijednosti.BringToFront();
            } else {

                FakText = CalculateFactorialLoop(FakText);
                Ispis.Text = FakText.ToString();

            }

            if (StirlingBroj < 0)
            {
                Upisvrijednosti.Show();
                Upisvrijednosti.BringToFront();
            }
            else
            {

                StirlingBroj = CalculateFactorialStirling(StirlingBroj);
                textBox1.Text = StirlingBroj.ToString();
            }
            if (FakText < 0 && StirlingBroj < 0)
            {
                Upisvrijednosti.Show();
                Upisvrijednosti.BringToFront();
            }
            else
            {
                doubleFak = CalculateFactorialLoop2(n);
                double apsolutna_greska = Math.Abs(doubleFak - StirlingBroj);

                textBox2.Text = apsolutna_greska.ToString();
                textBox3.Text = ((Math.Abs((doubleFak - StirlingBroj) / doubleFak) * 100)+ "%").ToString();
                
            }


        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void Faktorijel_Load(object sender, EventArgs e)
        {

        }

        private void Upisvrijednosti_Click(object sender, EventArgs e)
        {

        }
    }
}
