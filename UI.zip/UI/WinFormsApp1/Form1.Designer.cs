﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.faktorijel1 = new WinFormsApp1.Faktorijel();
            
            this.permutacije1 = new WinFormsApp1.Permutacije();
            this.rekurizivniFaktorijel1 = new UI.RekurizivniFaktorijel();
            this.binomniKoeficijent1 = new UI.BinomniKoeficijent();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(40)))), ((int)(((byte)(59)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button1.Location = new System.Drawing.Point(0, 75);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 3, 6, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(210, 42);
            this.button1.TabIndex = 0;
            this.button1.Text = "For Loop Faktorijel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(40)))), ((int)(((byte)(59)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button3.Location = new System.Drawing.Point(0, 164);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 3, 6, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(210, 42);
            this.button3.TabIndex = 2;
            this.button3.Text = "Binomni Koeficijent";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(210, 452);
            this.panel1.TabIndex = 5;
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(40)))), ((int)(((byte)(59)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button5.Location = new System.Drawing.Point(0, 116);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 3, 6, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(210, 42);
            this.button5.TabIndex = 8;
            this.button5.Text = "Rekurzivni Faktorijel";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.MaximumSize = new System.Drawing.Size(200, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Primjenjena Matematika - Program";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(40)))), ((int)(((byte)(59)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button4.Location = new System.Drawing.Point(3, 212);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 3, 6, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(210, 42);
            this.button4.TabIndex = 3;
            this.button4.Text = "Permutacije";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // faktorijel1
            // 
            this.faktorijel1.BackColor = System.Drawing.Color.Transparent;
            this.faktorijel1.Location = new System.Drawing.Point(216, 8);
            this.faktorijel1.Name = "faktorijel1";
            this.faktorijel1.Size = new System.Drawing.Size(585, 444);
            this.faktorijel1.TabIndex = 6;
            this.faktorijel1.Load += new System.EventHandler(this.faktorijel1_Load);
            // 
            // permutacije1
            // 
            this.permutacije1.BackColor = System.Drawing.Color.Transparent;
            this.permutacije1.Location = new System.Drawing.Point(216, 8);
            this.permutacije1.Name = "permutacije1";
            this.permutacije1.Size = new System.Drawing.Size(585, 444);
            this.permutacije1.TabIndex = 5;
            // 
            // rekurizivniFaktorijel1
            // 
            this.rekurizivniFaktorijel1.BackColor = System.Drawing.Color.Transparent;
            this.rekurizivniFaktorijel1.Location = new System.Drawing.Point(216, 8);
            this.rekurizivniFaktorijel1.Name = "rekurizivniFaktorijel1";
            this.rekurizivniFaktorijel1.Size = new System.Drawing.Size(585, 444);
            this.rekurizivniFaktorijel1.TabIndex = 7;
            this.rekurizivniFaktorijel1.Load += new System.EventHandler(this.rekurizivniFaktorijel1_Load);
            // 
            // binomniKoeficijent1
            // 
            this.binomniKoeficijent1.BackColor = System.Drawing.Color.Transparent;
            this.binomniKoeficijent1.Location = new System.Drawing.Point(216, 8);
            this.binomniKoeficijent1.Name = "binomniKoeficijent1";
            this.binomniKoeficijent1.Size = new System.Drawing.Size(585, 444);
            this.binomniKoeficijent1.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(37)))), ((int)(((byte)(55)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.faktorijel1);
            this.Controls.Add(this.permutacije1);
            this.Controls.Add(this.binomniKoeficijent1);
            this.Controls.Add(this.rekurizivniFaktorijel1);
            
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Button button1;
        private Button button3;
        
        private Panel panel1;
        private Button button4;
        private Faktorijel faktorijel1;
        
        private Permutacije permutacije1;
        private Label label1;
        private UI.RekurizivniFaktorijel rekurizivniFaktorijel1;
        private Button button5;
        private UI.BinomniKoeficijent binomniKoeficijent1;
    }
}