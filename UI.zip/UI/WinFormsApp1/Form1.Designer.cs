﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.faktorijel1 = new WinFormsApp1.Faktorijel();
            this.stirling1 = new WinFormsApp1.Stirling();
            this.binomniKoeficijent1 = new WinFormsApp1.BinomniKoeficijent();
            this.permutacije1 = new WinFormsApp1.Permutacije();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(40)))), ((int)(((byte)(59)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button1.Location = new System.Drawing.Point(0, 75);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 3, 6, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(210, 42);
            this.button1.TabIndex = 0;
            this.button1.Text = "Faktorijel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(40)))), ((int)(((byte)(59)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button2.Location = new System.Drawing.Point(0, 114);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 3, 6, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(210, 42);
            this.button2.TabIndex = 1;
            this.button2.Text = "Stirlingova Formula";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(40)))), ((int)(((byte)(59)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button3.Location = new System.Drawing.Point(0, 153);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 3, 6, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(210, 42);
            this.button3.TabIndex = 2;
            this.button3.Text = "Binomni Koeficijent";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(210, 452);
            this.panel1.TabIndex = 5;
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(40)))), ((int)(((byte)(59)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button4.Location = new System.Drawing.Point(0, 192);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 3, 6, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(210, 42);
            this.button4.TabIndex = 3;
            this.button4.Text = "Permutacije";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // faktorijel1
            // 
            this.faktorijel1.BackColor = System.Drawing.Color.Transparent;
            this.faktorijel1.Location = new System.Drawing.Point(216, 8);
            this.faktorijel1.Name = "faktorijel1";
            this.faktorijel1.Size = new System.Drawing.Size(585, 459);
            this.faktorijel1.TabIndex = 6;
            // 
            // stirling1
            // 
            this.stirling1.BackColor = System.Drawing.Color.Transparent;
            this.stirling1.Location = new System.Drawing.Point(216, 8);
            this.stirling1.Name = "stirling1";
            this.stirling1.Size = new System.Drawing.Size(585, 459);
            this.stirling1.TabIndex = 5;
            this.stirling1.Load += new System.EventHandler(this.stirling1_Load);
            // 
            // binomniKoeficijent1
            // 
            this.binomniKoeficijent1.BackColor = System.Drawing.Color.Transparent;
            this.binomniKoeficijent1.Location = new System.Drawing.Point(216, 8);
            this.binomniKoeficijent1.Name = "binomniKoeficijent1";
            this.binomniKoeficijent1.Size = new System.Drawing.Size(585, 444);
            this.binomniKoeficijent1.TabIndex = 5;
            // 
            // permutacije1
            // 
            this.permutacije1.BackColor = System.Drawing.Color.Transparent;
            this.permutacije1.Location = new System.Drawing.Point(216, 8);
            this.permutacije1.Name = "permutacije1";
            this.permutacije1.Size = new System.Drawing.Size(585, 438);
            this.permutacije1.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(37)))), ((int)(((byte)(55)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.faktorijel1);
            this.Controls.Add(this.permutacije1);
            this.Controls.Add(this.binomniKoeficijent1);
            this.Controls.Add(this.stirling1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        
        private Panel panel1;
        private Button button4;
        private Faktorijel faktorijel1;
        private Stirling stirling1;
        private BinomniKoeficijent binomniKoeficijent1;
        private Permutacije permutacije1;
    }
}