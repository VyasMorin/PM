namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            permutacije1.Hide();
            
            faktorijel1.Show();
            faktorijel1.BringToFront();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

       

       

        private void button3_Click(object sender, EventArgs e)
        {
            
            permutacije1.Hide();
            faktorijel1.Hide();
            rekurizivniFaktorijel1.Hide();
            binomniKoeficijent1.Show();
            binomniKoeficijent1.BringToFront();
            
        }
        private void button4_Click(object sender, EventArgs e)
        {
            
            
            faktorijel1.Hide();
            permutacije1.Show();
            permutacije1.BringToFront();
        }

        private void stirling1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void faktorijel1_Load(object sender, EventArgs e)
        {

        }

        private void rekurizivniFaktorijel1_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            
            
            faktorijel1.Hide();
            permutacije1.Hide();
            rekurizivniFaktorijel1.Show();
            rekurizivniFaktorijel1.BringToFront();
        }
    }
}