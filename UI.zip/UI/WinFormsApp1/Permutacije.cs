﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Permutacije : UserControl
    {
        public Permutacije()
        {
            InitializeComponent();
        }
        static decimal fact(decimal n)
        {
            if (n <= 1)
                return 1;
            return n * fact(n - 1);
        }
        static decimal Permutacija(int broj1, int broj2)
        {
            

            decimal n = broj1;
            decimal r = broj2;
            decimal perm;
            



            

           
               perm =fact(n) / fact(n - r);


            return perm;

        }
        int broj1 = 0;
        int broj2 = 0;
        decimal broj3 = 0;
        

        private void Permutacijus_Click(object sender, EventArgs e)
        {
            broj1 = Convert.ToInt32(Upis.Text);
            broj2 = Convert.ToInt32(Upis2.Text);
            if(broj1 <0 || broj2 < 0) {

                Upisvrijednosti.Show();
                Upisvrijednosti.BringToFront();

            }else if (broj2 > broj1)
            {
                DrugiBrojNeSmije.Show();
                DrugiBrojNeSmije.BringToFront();
            }
            else {
                
                Upisvrijednosti.Hide();
                DrugiBrojNeSmije.Hide();
            broj3 = Permutacija(broj1, broj2);
            Ispis.Text = broj3.ToString();
            }
        }
    }
}
