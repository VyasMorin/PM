﻿namespace UI
{
    partial class RekurizivniFaktorijel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Rekurziraj = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Ispis = new System.Windows.Forms.TextBox();
            this.Upis = new System.Windows.Forms.TextBox();
            this.Upisvrijednosti = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Rekurziraj
            // 
            this.Rekurziraj.Location = new System.Drawing.Point(267, 148);
            this.Rekurziraj.Name = "Rekurziraj";
            this.Rekurziraj.Size = new System.Drawing.Size(83, 23);
            this.Rekurziraj.TabIndex = 9;
            this.Rekurziraj.Text = "Rekurziraj";
            this.Rekurziraj.UseVisualStyleBackColor = true;
            this.Rekurziraj.Click += new System.EventHandler(this.Rekurziraj_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Location = new System.Drawing.Point(204, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "Upis";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Location = new System.Drawing.Point(204, 203);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "Ispis";
            // 
            // Ispis
            // 
            this.Ispis.Location = new System.Drawing.Point(204, 221);
            this.Ispis.Name = "Ispis";
            this.Ispis.Size = new System.Drawing.Size(228, 23);
            this.Ispis.TabIndex = 6;
            // 
            // Upis
            // 
            this.Upis.Location = new System.Drawing.Point(204, 86);
            this.Upis.Name = "Upis";
            this.Upis.Size = new System.Drawing.Size(228, 23);
            this.Upis.TabIndex = 5;
            // 
            // Upisvrijednosti
            // 
            this.Upisvrijednosti.AutoSize = true;
            this.Upisvrijednosti.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Upisvrijednosti.ForeColor = System.Drawing.Color.Red;
            this.Upisvrijednosti.Location = new System.Drawing.Point(144, 36);
            this.Upisvrijednosti.MaximumSize = new System.Drawing.Size(500, 0);
            this.Upisvrijednosti.Name = "Upisvrijednosti";
            this.Upisvrijednosti.Size = new System.Drawing.Size(425, 32);
            this.Upisvrijednosti.TabIndex = 32;
            this.Upisvrijednosti.Text = "Upis negativnih vrijednosti nije moguc";
            this.Upisvrijednosti.Visible = false;
            // 
            // RekurizivniFaktorijel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.Upisvrijednosti);
            this.Controls.Add(this.Rekurziraj);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Ispis);
            this.Controls.Add(this.Upis);
            this.Name = "RekurizivniFaktorijel";
            this.Size = new System.Drawing.Size(882, 466);
            this.Load += new System.EventHandler(this.RekurizivniFaktorijel_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button Rekurziraj;
        private Label label2;
        private Label label1;
        private TextBox Ispis;
        private TextBox Upis;
        private Label Upisvrijednosti;
    }
}
