﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Numerics;

namespace UI
{
    public partial class RekurizivniFaktorijel : UserControl
    {
        public RekurizivniFaktorijel()
        {
            InitializeComponent();
        }
        static BigInteger CalculateFactorialRecursive(BigInteger n)
        {
            if (n < 0)
            {
                throw new ArgumentException("Input must be a non-negative integer.");
            }
            if (n == 0 || n == 1)
            {
                return 1;
            }
            else
            {
                return n * CalculateFactorialRecursive(n - 1);
            }
        }
        private void RekurizivniFaktorijel_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        BigInteger RekBroj = 0;

        private void Rekurziraj_Click(object sender, EventArgs e)
        {
            RekBroj = BigInteger.Parse(Upis.Text);
            if(RekBroj < 0)
            {
                Upisvrijednosti.Show();
                Upisvrijednosti.BringToFront();
            }else { 
            RekBroj = CalculateFactorialRecursive(RekBroj);
            Ispis.Text = RekBroj.ToString();
        }
        }
    }
}
