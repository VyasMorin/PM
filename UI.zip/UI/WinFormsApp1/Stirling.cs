﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Numerics;

namespace WinFormsApp1
{
    public partial class Stirling : UserControl
    {
        public Stirling()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        public static double CalculateFactorialStirling(double n)
        {
            if (n < 0)
            {
                throw new ArgumentException("Input must be a non-negative integer.");
            }
            return Math.Sqrt(2.0 * Math.PI * n) * Math.Pow((n / Math.E), n);
        }
        double StirlingBroj = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            StirlingBroj = Convert.ToDouble(Upis.Text);
            if(StirlingBroj < 0)
            {
                Upisvrijednosti.Show();
                Upisvrijednosti.BringToFront();
            }else {
                
                StirlingBroj = CalculateFactorialStirling(StirlingBroj);
            Ispis.Text = StirlingBroj.ToString();
            }

        }
    }
}
