﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class BinomniKoeficijent : UserControl
    {
        public BinomniKoeficijent()
        {
            InitializeComponent();
        }
        static BigInteger BinomlaniKoeficijent(int broj1, int broj2)
        {
            int broj3 = broj1 - broj2;

            BigInteger[] faktorijeli = new BigInteger[3];


            faktorijeli[0] = broj1;
            faktorijeli[1] = broj2;
            faktorijeli[2] = broj3;
            BigInteger jedan = 1;


            for (int i = 1; i <= broj1 - 1; i++)
            {

                faktorijeli[0] = faktorijeli[0] * i;
            }
            for (int i = 1; i <= broj2 - 1; i++)
            {

                faktorijeli[1] = faktorijeli[1] * i;
            }
            for (int i = 1; i <= broj3 - 1; i++)
            {


                faktorijeli[2] = faktorijeli[2] * i;
            }
            BigInteger faktorijel4;

            if (faktorijeli[1] == 0 || faktorijeli[2] == 0) faktorijel4 = faktorijeli[0] / faktorijeli[0];
            else faktorijel4 = faktorijeli[0] / (faktorijeli[1] * faktorijeli[2]);

            return faktorijel4;

        }
        private void BinomniKoeficijent_Load(object sender, EventArgs e)
        {

        }
        int broj = 0;
        int broj2 = 0;
        BigInteger broj3 = 0;
        private void Binom_Click(object sender, EventArgs e)
        {
            broj = Convert.ToInt32(Upis.Text);
            broj2 = Convert.ToInt32(Upis2.Text);
            broj3 = BinomlaniKoeficijent(broj, broj2);
            Ispis.Text = broj3.ToString(); 
        }
    }
}
