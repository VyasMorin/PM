﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Numerics;

namespace WinFormsApp1
{
    public partial class Faktorijel : UserControl
    {
        public Faktorijel()
        {
            InitializeComponent();
        }
        static BigInteger CalculateFactorialLoop(BigInteger n)
        {
            if (n < 0)
            {
                throw new ArgumentException("Input must be a non-negative integer.");
            }

            BigInteger factorial = 1;
            for (int i = 1; i <= n; i++)
            {
                factorial *=i;
            }

            return factorial;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        BigInteger FakText = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            

            FakText = BigInteger.Parse(Upis.Text);
            FakText = CalculateFactorialLoop(FakText);
            Ispis.Text = FakText.ToString();
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void Faktorijel_Load(object sender, EventArgs e)
        {

        }
    }
}
