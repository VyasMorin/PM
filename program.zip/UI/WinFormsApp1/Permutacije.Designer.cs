﻿namespace WinFormsApp1
{
    partial class Permutacije
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Upis2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Ispis = new System.Windows.Forms.TextBox();
            this.Upis = new System.Windows.Forms.TextBox();
            this.Permutacijus = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Upis2
            // 
            this.Upis2.Location = new System.Drawing.Point(204, 115);
            this.Upis2.Name = "Upis2";
            this.Upis2.Size = new System.Drawing.Size(228, 23);
            this.Upis2.TabIndex = 21;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Location = new System.Drawing.Point(204, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 15);
            this.label2.TabIndex = 19;
            this.label2.Text = "Upis";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Location = new System.Drawing.Point(204, 203);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 15);
            this.label1.TabIndex = 18;
            this.label1.Text = "Ispis";
            // 
            // Ispis
            // 
            this.Ispis.Location = new System.Drawing.Point(204, 221);
            this.Ispis.Name = "Ispis";
            this.Ispis.Size = new System.Drawing.Size(228, 23);
            this.Ispis.TabIndex = 17;
            // 
            // Upis
            // 
            this.Upis.Location = new System.Drawing.Point(204, 86);
            this.Upis.Name = "Upis";
            this.Upis.Size = new System.Drawing.Size(228, 23);
            this.Upis.TabIndex = 16;
            // 
            // Permutacijus
            // 
            this.Permutacijus.Location = new System.Drawing.Point(267, 148);
            this.Permutacijus.Name = "Permutacijus";
            this.Permutacijus.Size = new System.Drawing.Size(83, 23);
            this.Permutacijus.TabIndex = 29;
            this.Permutacijus.Text = "Permutiziraj";
            this.Permutacijus.UseVisualStyleBackColor = true;
            this.Permutacijus.Click += new System.EventHandler(this.Permutacijus_Click);
            // 
            // Permutacije
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.Permutacijus);
            this.Controls.Add(this.Upis2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Ispis);
            this.Controls.Add(this.Upis);
            this.Name = "Permutacije";
            this.Size = new System.Drawing.Size(666, 497);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox Upis2;
        
        private Label label2;
        private Label label1;
        private TextBox Ispis;
        private TextBox Upis;
        private Button Permutacijus;
    }
}
