﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Permutacije : UserControl
    {
        public Permutacije()
        {
            InitializeComponent();
        }

        static BigInteger Permutacija(int broj1, int broj2)
        {
            int broj3 = broj1 - broj2;

            BigInteger[] faktorijeli = new BigInteger[3];


            faktorijeli[0] = broj1;
            faktorijeli[1] = broj2;
            faktorijeli[2] = broj3;
            BigInteger jedan = 1;


            for (int i = 1; i <= broj1 - 1; i++)
            {

                faktorijeli[0] = faktorijeli[0] * i;
            }
            
            for (int i = 1; i <= broj3 - 1; i++)
            {


                faktorijeli[2] = faktorijeli[2] * i;
            }
            BigInteger faktorijel4;

            if (faktorijeli[1] == 0 || faktorijeli[2] == 0) faktorijel4 = faktorijeli[0] / faktorijeli[0];
            else faktorijel4 = faktorijeli[0] /  faktorijeli[2];

            return faktorijel4;

        }
        int broj1 = 0;
        int broj2 = 0;
        BigInteger broj3 = 0;
        

        private void Permutacijus_Click(object sender, EventArgs e)
        {
            broj1 = Convert.ToInt32(Upis.Text);
            broj2 = Convert.ToInt32(Upis2.Text);
            broj3 = Permutacija(broj1, broj2);
            Ispis.Text = broj3.ToString();
        }
    }
}
